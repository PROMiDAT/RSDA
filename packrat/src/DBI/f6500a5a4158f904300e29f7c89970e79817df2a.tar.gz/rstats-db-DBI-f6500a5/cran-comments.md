Addresses a glitch in the default `dbReadTable()` implementation now provided by DBI.

## Test environments
* ubuntu 16.04 (local install), R 3.3.3
* ubuntu 12.04 (on travis-ci), R devel, release, and oldrel
* win-builder (release and devel)


## R CMD check results

0 errors | 0 warnings | 1 note

Found the following apparent S3 methods exported but not registered:
  print.list.pairs

- print.list.pairs() has been deprecated and will be removed soon.


## Reverse dependencies

Minor update, reverse dependencies not checked.
